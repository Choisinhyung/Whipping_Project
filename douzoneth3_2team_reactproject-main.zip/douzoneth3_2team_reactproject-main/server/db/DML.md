
## PRODUCTS


insert into products(name,provider,price,image,category,gender,categorydetail) values('아더에러 x 자라 패치워크 오버사이즈 니트 스웨터 멀티컬러','Ader Error','313000','/images/image001.png','의류','1','3사이즈');
insert into products(name,provider,price,image,category,gender,categorydetail) values('스투시 x 데님 티어스 타입 2 자켓 라이트 인디고','Stussy','990000','/images/image002.png','의류','1','3사이즈');
insert into products(name,provider,price,image,category,gender,categorydetail) values('넘버링 1901 A13 워치 브레이슬릿 블랙 스트랩 실버','Numbering','198000','/images/image003.png','패션잡화','1','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('오프화이트 x 포스트 아카이브 팩션 피규어 오브 스피치 캡 라이트 블랙','Off-White','188000','/images/image004.png','패션잡화','1','3사이즈');
insert into products(name,provider,price,image,category,gender,categorydetail) values('폴리테루 리소 데님 인디고 22FW','Polyteru','164000','/images/image005.png','의류','1','3사이즈');
insert into products(name,provider,price,image,category,gender,categorydetail) values('알레그리 캐시미어 리치 30 핸드메이드 더블 칼라 세미 오버 로브 코트 제트 블랙','Allegri','1170000','/images/image006.png','의류','2','3사이즈');
insert into products(name,provider,price,image,category,gender,categorydetail) values('애플 아이폰 13 프로 맥스 128GB 그래파이트','Kracker','1319000','/images/image007.png','테크','2','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('아더에러 x 자라 백팩 블랙','Ader Error','280000','/images/image008.png','라이프','2','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('피어 오브 갓 베이스볼 후드 빈티지 블랙','Fear of God','467000','/images/image009.png','의류','1','3사이즈');
insert into products(name,provider,price,image,category,gender,categorydetail) values('텐씨 아틱 다운 파카 그레이','TenC','830000','/images/image010.png','의류','1','3사이즈');
insert into products(name,provider,price,image,category,gender,categorydetail) values('언더마이카 리전.04 멀티 지퍼 배기 와이드 슬랙스 블랙','Undermycar','189000','/images/image011.png','의류','1','3사이즈');
insert into products(name,provider,price,image,category,gender,categorydetail) values('롤렉스 씨드웰러 126600','Rolex','17600000','/images/image012.png','패션잡화','1','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('슈프림 벨벳 패턴 트루퍼 라이트 블루 - 21FW','Supreme','228000','/images/image013.png','패션잡화','1','3사이즈');
insert into products(name,provider,price,image,category,gender,categorydetail) values('튜더 블랙 베이 크로노 MT5813 스틸 브레이슬릿 오팔린','Tudor','5900000','/images/image014.png','패션잡화','1','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('노스페이스 눕시 쇼트 자켓 블랙','TheNorthFace','649000','/images/image015.png','의류','2','3사이즈');
insert into products(name,provider,price,image,category,gender,categorydetail) values('막스마라 루드밀라 아이콘 코트 토바코','MaxMara','4150000','/images/image016.png','의류','2','3사이즈');
insert into products(name,provider,price,image,category,gender,categorydetail) values('디젤 엠아리사 점퍼 자수 컷아웃 로고 니트 블랙','Diesel','599000','/images/image017.png','의류','2','3사이즈');
insert into products(name,provider,price,image,category,gender,categorydetail) values('비비안 웨스트우드 투 사이드 싱글 오브 스카프 카멜','Vivienne Westwood','217000','/images/image018.png','패션잡화','2','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('셀린느 트리옴페 캔버스 & 카프스킨 미디움 폴코백 탄','Celine','2100000','/images/image019.png','패션잡화','2','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('반 클리프 & 아펠 스위트 알함브라 펜던트 옐로우 골드 마더 오브 펄','Van Cleef & Arpels','2110000','/images/image020.png','패션잡화','2','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('딥티크 플레르 드 뽀 오 드 퍼퓸 75ml (국내 정식 발매 제품)','Diptyque','227000','/images/image021.png','라이프','3','향수');
insert into products(name,provider,price,image,category,gender,categorydetail) values('딥티크 오르페옹 오 드 퍼퓸 75ml (국내 정식 발매 제품)','Diptyque','215000','/images/image022.png','라이프','3','향수');
insert into products(name,provider,price,image,category,gender,categorydetail) values('케이스티파이 x 아더에러 아이폰 스티커 맥세이프 케이스 클리어','Casetify','113000','/images/image023.png','라이프','3','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('헬리녹스 택티컬 필드 터널 4.35 코요테 탄','Helinox','4950000','/images/image024.png','라이프','3','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('레고 빈센트 반 고흐 별이 빛나는 밤','Lego','201000','/images/image025.png','라이프','3','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('톰포드 오드 우드 오 드 퍼퓸 100ml (국내 정식 발매 제품)','Tom Ford','338000','/images/image026.png','라이프','3','향수');
insert into products(name,provider,price,image,category,gender,categorydetail) values('포켓몬 카드 게임 소드&실드 하이클래스팩 브이맥스 클라이맥스 4박스 (총 40팩)','Pokemon','375000','/images/image027.png','라이프','3','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('오프화이트 x 아모레 퍼시픽 프로텍션 박스','Off-White','34000','/images/image028.png','라이프','3','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('레고 바라쿠다 해적들','Lego','432000','/images/image029.png','라이프','3','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('레고 대형 백화점','Lego','481000','/images/image030.png','라이프','3','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('애플 에어팟 맥스 실버 (국내 정식 발매 제품)','Apple','693000','/images/image031.png','테크','3','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('애플 에어팟 프로 2세대 (국내 정식 발매 제품)','Apple','309000','/images/image032.png','테크','1','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('마이크로소프트 엑스박스 시리즈 X (국내 정식 발매 제품)','Microsoft','584000','/images/image033.png','테크','1','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('애플 에어팟 프로 맥세이프 호환 (국내 정식 발매 제품)','Apple','248000','/images/image034.png','테크','3','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('애플 에어팟 맥스 스페이스 그레이 (국내 정식 발매 제품)','Apple','681000','/images/image035.png','테크','3','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('소니 플레이스테이션 5 블루레이 에디션 (국내 정식 발매 제품)','Sony','713000','/images/image036.png','테크','3','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('소니 플레이스테이션 5 디지털 에디션 (국내 정식 발매 제품)','Sony','590000','/images/image037.png','테크','3','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('애플 아이패드 에어 5세대 와이파이 64기가 스페이스 그레이 (국내 정식 발매 제품)','Apple','728000','/images/image038.png','테크','2','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('애플 아이폰 14 프로 128기가 스페이스 블랙 (국내 정식 발매 제품)','Apple','1506000','/images/image039.png','테크','2','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('애플 아이폰 14 프로 256기가 실버 (국내 정식 발매 제품)','Apple','1609000','/images/image040.png','테크','1','onesize');

insert into products(name,provider,price,image,category,gender,categorydetail) values('아디다스 퍼피렛 오프 화이트','Adidas','125000','/images/image041.png','패션잡화','1','신발');
insert into products(name,provider,price,image,category,gender,categorydetail) values('아워레가시 카미온 부츠 블랙','OurLegacy','483000','/images/image042.png','패션잡화','2','신발');
insert into products(name,provider,price,image,category,gender,categorydetail) values('어그 코케트 슬리퍼 그레이','UGG','122000','/images/image043.png','패션잡화','3','신발');

insert into products(name,provider,price,image,category,gender,categorydetail) values('레고 크리스마스 화환 2-in-1','Lego','59000','/images/image044.png','크리스마스추천','3','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('넘버링 5400 체인 오픈 링 골드','Numbering','126000','/images/image045.png','크리스마스추천','3','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('슈프림 크리스마스 트리 토퍼 골드 - 21FW','Supreme','166000','/images/image046.png','크리스마스추천','3','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('티파니 앤 코 리턴 투 티파니 블루 더블 하트 태그 펜던트 미니 실버','Tiffany & Co.','418000','/images/image047.png','크리스마스추천','3','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('레고 크리스마스 트리','Lego','95000','/images/image048.png','크리스마스추천','3','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('샤넬 넘버5 오 드 빠르펭 100ml (국내 정식 발매 제품)','Chanel','217000','/images/image049.png','크리스마스추천','3','향수');
insert into products(name,provider,price,image,category,gender,categorydetail) values('플레이모빌 산타 XXL','Playmobil','131000','/images/image050.png','크리스마스추천','3','onesize');
insert into products(name,provider,price,image,category,gender,categorydetail) values('(W) 샤넬 이어링 메탈 디아만테 & 골드 크리스탈','Chanel','1040000','/images/image051.png','크리스마스추천','3','onesize');

SELECT * FROM PRODUCTS;
commit;

---


## USER

insert into user(userid,username,userpassword,useremail,userphonenumber,useraddress) values('sinyeon','신형','12345678','brandnew@naver.com','010-1321-3433','서울특별시 종로구 혜화동');
insert into user(userid,username,userpassword,useremail,userphonenumber,useraddress) values('hojin','호진','1216','rhjhojin@naver.com','010-5565-4343','서울특별시 종로구 혜화동');
insert into user(userid,username,userpassword,useremail,userphonenumber,useraddress) values('kbm0225','보민','33333333','kkbm0225@naver.com','010-2589-6783','서울특별시 종로구 혜화동');

insert into user(userid,username,userpassword,useremail,userphonenumber,useraddress) values('kkbm0225','보민','alwlqhals','kbm0225@naver.com','010-5285-6697','서울특별시 종로구 혜화동');

SELECT * FROM USER;
COMMIT;

---
## SALE

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(1,'sinyeon',300000,'M');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(1,'kbm0225',280000,'S');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(1,'kbm0225',290000,'M');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(1,'hojin',310000,'L');

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(2,'kbm0225',140000,'XS');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(2,'hojin',160000,'M');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(2,'kbm0225',320000,'L');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(2,'hojin',310000,'L');

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(3,'sinyeon',400000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(3,'kbm0225',420000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(3,'hojin',500000,'onesize');

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(4,'sinyeon',1000000,'XS');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(4,'kbm0225',1100000,'S');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(4,'hojin',1200000,'S');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(4,'kbm0225',1500000,'L');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(4,'hojin',1550000,'XL');

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(5,'sinyeon',100000,'XS');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(5,'kbm0225',110000,'S');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(5,'hojin',130000,'S');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(5,'kbm0225',210000,'M');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(5,'hojin',250000,'XL');

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(6,'sinyeon',800000,'XS');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(6,'kbm0225',910000,'S');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(6,'hojin',920000,'M');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(6,'kbm0225',950000,'M');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(6,'hojin',1000000,'XL');

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(7,'sinyeon',1300000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(7,'hojin',1400000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(7,'kbm0225',1550000,'onesize');

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(8,'sinyeon',260000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(8,'kbm0225',270000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(8,'sinyeon',290000,'onesize');

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(9,'sinyeon',370000,'XS');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(9,'kbm0225',360000,'S');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(9,'hojin',380000,'S');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(9,'kbm0225',410000,'L');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(9,'hojin',390000,'XL');

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(10,'sinyeon',900000,'XS');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(10,'kbm0225',1000000,'S');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(10,'hojin',1200000,'M');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(10,'kbm0225',1500000,'M');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(10,'hojin',1300000,'XL');

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(11,'sinyeon',110000,'XS');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(11,'kbm0225',210000,'S');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(11,'hojin',230000,'M');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(11,'kbm0225',250000,'L');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(11,'hojin',370000,'XL');

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(12,'sinyeon',19000000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(12,'kbm0225',20000000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(12,'hojin',22000000,'onesize');

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(13,'sinyeon',890000,'XS');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(13,'kbm0225',950000,'S');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(13,'hojin',1000000,'M');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(13,'kbm0225',1005000,'L');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(13,'hojin',1300000,'XL');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(13,'kbm0225',1400000,'XL');

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(14,'sinyeon',450000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(14,'kbm0225',500000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(14,'hojin',520000,'onesize');

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(15,'sinyeon',450000,'XS');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(15,'kbm0225',460000,'S');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(15,'hojin',500000,'M');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(15,'kbm0225',550000,'L');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(15,'hojin',570000,'XL');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(15,'kbm0225',590000,'XL');

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(16,'sinyeon',4150000,'XS');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(16,'kbm0225',4200000,'S');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(16,'hojin',4200000,'M');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(16,'kbm0225',4500000,'L');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(16,'hojin',4500000,'L');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(16,'kbm0225',4800000,'XL');

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(17,'sinyeon',600000,'XS');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(17,'kbm0225',620000,'S');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(17,'hojin',650000,'M');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(17,'kbm0225',670000,'L');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(17,'hojin',670000,'XL');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(17,'kbm0225',690000,'XL');

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(18,'sinyeon',210000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(18,'kbm0225',220000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(18,'hojin',250000,'onesize');

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(19,'sinyeon',2100000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(19,'kbm0225',2200000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(19,'hojin',2300000,'onesize');

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(20,'sinyeon',450000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(20,'kbm0225',500000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(20,'hojin',520000,'onesize');


insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(21,'sinyeon',217000,'size_30ml');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(21,'kbm0225',200000,'size_30ml');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(21,'sinyeon',317000,'size_100ml');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(21,'kbm0225',318000,'size_100ml');

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(22,'sinyeon',215000,'size_30ml');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(22,'kbm0225',222000,'size_30ml');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(22,'sinyeon',307000,'size_100ml');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(22,'kbm0225',308000,'size_100ml');

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(23,'sinyeon',113000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(23,'kbm0225',115000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(23,'hojin',118000,'onesize');

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(24,'sinyeon',4950000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(24,'kbm0225',5000000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(24,'hojin',5100000,'onesize');

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(25,'sinyeon',201000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(25,'kbm0225',210000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(25,'hojin',220000,'onesize');

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(26,'sinyeon',205000,'size_30ml');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(26,'kbm0225',210000,'size_30ml');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(26,'hojin',315000,'size_100ml');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(26,'sinyeon',320000,'size_100ml');

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(27,'sinyeon',375000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(28,'kbm0225',34000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(29,'hojin',432000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(30,'sinyeon',481000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(31,'kbm0225',693000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(32,'hojin',309000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(33,'sinyeon',584000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(34,'kbm0225',248000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(35,'hojin',681000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(36,'kbm0225',713000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(37,'hojin',590000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(38,'sinyeon',728000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(39,'kbm0225',1506000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(40,'hojin',1609000,'onesize');

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(41,'sinyeon',120000,'size_225');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(41,'kbm0225',140000,'size_230');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(41,'hojin',210000,'size_245');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(41,'kbm0225',300000,'size_255');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(41,'sinyeon',250000,'size_265');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(41,'hojin',150000,'size_280');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(41,'sinyeon',170000,'size_285');

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(42,'hojin',480000,'size_230');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(42,'sinyeon',650000,'size_250');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(42,'kbm0225',700000,'size_255');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(42,'kbm0225',550000,'size_265');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(42,'hojin',500000,'size_280');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(42,'sinyeon',510000,'size_285');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(42,'kbm0225',450000,'size_295');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(42,'kbm0225',430000,'size_300');


insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(43,'hojin',480000,'size_230');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(43,'hojin',490000,'size_235');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(43,'sinyeon',630000,'size_240');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(43,'kbm0225',600000,'size_245');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(43,'sinyeon',650000,'size_250');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(43,'kbm0225',700000,'size_255');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(43,'kbm0225',550000,'size_265');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(43,'hojin',500000,'size_280');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(43,'sinyeon',510000,'size_285');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(43,'kbm0225',450000,'size_295');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(43,'kbm0225',430000,'size_300');


insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(43,'hojin',122000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(44,'sinyeon',59000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(45,'kbm0225',126000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(46,'hojin',166000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(47,'kbm0225',418000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(48,'hojin',95000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(49,'sinyeon',217000,'size_30ml');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(49,'sinyeon',218000,'size_100ml');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(50,'kbm0225',131000,'onesize');
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE) values(51,'hojin',1040000,'onesize');


--- 
`판매기록 더미데이터 추가 : 재고 변동 없음`
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(1,'sinyeon',300000,'L',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(1,'kbm0225',282000,'L',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(1,'kbm0225',293000,'L',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(1,'hojin',310000,'L',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(1,'hojin',315000,'L',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(1,'sinyeon',300000,'L',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(1,'kbm0225',282000,'L',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(1,'kbm0225',293000,'L',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(1,'hojin',310000,'L',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(1,'hojin',315000,'L',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(2,'sinyeon',800000,'S',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(2,'kbm0225',850000,'M',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(2,'hojin',910000,'XL',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(2,'hojin',800000,'S',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(2,'sinyeon',850000,'M',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(2,'kbm0225',910000,'XL',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(3,'sinyeon',180000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(3,'kbm0225',185000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(3,'hojin',187000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(3,'hojin',180000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(3,'sinyeon',185000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(3,'kbm0225',187000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(4,'sinyeon',180000,'XS',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(4,'kbm0225',185000,'S',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(4,'hojin',187000,'L',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(4,'hojin',180000,'XS',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(4,'sinyeon',185000,'S',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(4,'kbm0225',187000,'L',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(5,'sinyeon',164000,'XS',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(5,'kbm0225',165000,'S',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(5,'hojin',170000,'L',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(5,'hojin',164000,'XS',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(5,'sinyeon',165000,'S',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(5,'kbm0225',170000,'L',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(6,'sinyeon',1170000,'XS',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(6,'kbm0225',1200000,'S',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(6,'hojin',1250000,'L',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(6,'hojin',1170000,'XS',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(6,'sinyeon',1200000,'S',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(6,'kbm0225',1250000,'L',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(7,'sinyeon',1370000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(7,'kbm0225',1300000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(7,'hojin',1280000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(7,'hojin',1370000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(7,'sinyeon',1300000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(7,'kbm0225',1280000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(8,'sinyeon',280000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(8,'kbm0225',285000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(8,'hojin',290000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(8,'hojin',280000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(8,'sinyeon',285000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(8,'kbm0225',290000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(9,'sinyeon',460000,'S',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(9,'kbm0225',475000,'L',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(9,'hojin',470000,'XL',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(9,'hojin',460000,'S',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(9,'sinyeon',475000,'L',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(9,'kbm0225',470000,'XL',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(10,'sinyeon',830000,'S',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(10,'kbm0225',825000,'L',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(10,'hojin',825000,'XL',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(10,'hojin',830000,'S',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(10,'sinyeon',825000,'L',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(10,'kbm0225',825000,'XL',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(11,'sinyeon',189000,'M',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(11,'kbm0225',190000,'L',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(11,'hojin',192000,'XL',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(11,'hojin',189000,'M',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(11,'sinyeon',190000,'L',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(11,'kbm0225',192000,'XL',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(12,'sinyeon',17600000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(12,'kbm0225',18000000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(12,'hojin',19500000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(12,'hojin',17600000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(12,'sinyeon',18000000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(12,'kbm0225',19500000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(13,'sinyeon',228000,'S',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(13,'kbm0225',300000,'L',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(13,'hojin',320000,'XL',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(13,'hojin',228000,'S',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(13,'sinyeon',300000,'L',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(13,'kbm0225',320000,'XL',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(14,'sinyeon',5900000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(14,'kbm0225',6000000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(14,'hojin',6200000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(14,'hojin',590000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(14,'sinyeon',6000000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(14,'kbm0225',6200000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(15,'sinyeon',649000,'S',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(15,'kbm0225',650000,'L',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(15,'hojin',620000,'XL',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(15,'hojin',649000,'S',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(15,'sinyeon',650000,'L',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(15,'kbm0225',620000,'XL',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(16,'sinyeon',4150000,'S',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(16,'kbm0225',4100000,'L',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(16,'hojin',4400000,'XL',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(16,'hojin',4150000,'S',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(16,'sinyeon',4100000,'L',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(16,'kbm0225',4400000,'XL',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(17,'sinyeon',600000,'S',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(17,'kbm0225',620000,'L',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(17,'hojin',635000,'XL',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(17,'hojin',600000,'S',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(17,'sinyeon',620000,'L',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(17,'kbm0225',635000,'XL',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(18,'sinyeon',640000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(18,'kbm0225',650000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(18,'hojin',635000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(18,'hojin',640000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(18,'sinyeon',650000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(18,'kbm0225',635000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(19,'sinyeon',2100000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(19,'kbm0225',2200000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(19,'hojin',2050000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(19,'hojin',2100000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(19,'sinyeon',2200000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(19,'kbm0225',2050000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(20,'sinyeon',2100000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(20,'kbm0225',2110000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(20,'hojin',2130000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(20,'hojin',2100000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(20,'sinyeon',2110000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(20,'kbm0225',2130000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(21,'sinyeon',227000,'향수',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(21,'kbm0225',230000,'향수',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(21,'hojin',220000,'향수',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(21,'hojin',227000,'향수',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(21,'sinyeon',230000,'향수',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(21,'kbm0225',220000,'향수',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(22,'sinyeon',210000,'향수',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(22,'kbm0225',205000,'향수',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(22,'hojin',209000,'향수',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(22,'hojin',210000,'향수',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(22,'sinyeon',205000,'향수',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(22,'kbm0225',209000,'향수',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(23,'sinyeon',130000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(23,'kbm0225',142000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(23,'hojin',144000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(23,'hojin',130000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(23,'sinyeon',142000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(23,'kbm0225',144000,'onesize',1);


insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(24,'sinyeon',4980000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(24,'kbm0225',5080000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(24,'hojin',5000000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(24,'hojin',4980000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(24,'sinyeon',5080000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(24,'kbm0225',5000000,'onesize',1);


insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(26,'sinyeon',360000,'향수',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(26,'kbm0225',370000,'향수',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(26,'hojin',372000,'향수',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(26,'hojin',360000,'향수',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(26,'sinyeon',370000,'향수',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(26,'kbm0225',372000,'향수',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(27,'sinyeon',227000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(27,'kbm0225',225000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(27,'hojin',230000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(27,'hojin',227000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(27,'sinyeon',225000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(27,'kbm0225',230000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(28,'sinyeon',34000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(28,'kbm0225',30000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(28,'hojin',29000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(28,'hojin',34000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(28,'sinyeon',30000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(28,'kbm0225',29000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(29,'sinyeon',432000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(29,'kbm0225',440000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(29,'hojin',450000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(29,'hojin',432000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(29,'sinyeon',440000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(29,'kbm0225',450000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(30,'sinyeon',452000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(30,'kbm0225',470000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(30,'hojin',480000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(30,'hojin',452000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(30,'sinyeon',470000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(30,'kbm0225',480000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(31,'sinyeon',700000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(31,'kbm0225',710000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(31,'hojin',712000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(31,'hojin',700000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(31,'sinyeon',710000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(31,'kbm0225',712000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(32,'sinyeon',309000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(32,'kbm0225',310000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(32,'hojin',320000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(32,'hojin',309000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(32,'sinyeon',310000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(32,'kbm0225',320000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(33,'sinyeon',586000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(33,'kbm0225',595000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(33,'hojin',590000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(33,'hojin',586000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(33,'sinyeon',595000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(33,'kbm0225',590000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(34,'sinyeon',250000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(34,'kbm0225',244000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(34,'hojin',236000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(34,'hojin',250000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(34,'sinyeon',244000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(34,'kbm0225',236000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(35,'sinyeon',680000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(35,'kbm0225',675000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(35,'hojin',660000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(35,'hojin',680000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(35,'sinyeon',675000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(35,'kbm0225',660000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(36,'sinyeon',720000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(36,'kbm0225',721000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(36,'hojin',698000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(36,'hojin',720000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(36,'sinyeon',721000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(36,'kbm0225',698000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(37,'sinyeon',590000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(37,'kbm0225',600000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(37,'hojin',601000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(37,'hojin',590000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(37,'sinyeon',600000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(37,'kbm0225',601000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(38,'sinyeon',724000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(38,'kbm0225',715000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(38,'hojin',720000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(38,'hojin',724000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(38,'sinyeon',715000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(38,'kbm0225',720000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(39,'sinyeon',1055000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(39,'kbm0225',1060000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(39,'hojin',1080000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(39,'hojin',1055000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(39,'sinyeon',1060000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(39,'kbm0225',1080000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(44,'sinyeon',59000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(44,'kbm0225',61000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(44,'hojin',58000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(44,'hojin',59000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(44,'sinyeon',61000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(44,'kbm0225',58000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(45,'sinyeon',59000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(45,'kbm0225',130000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(45,'hojin',132000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(45,'hojin',132000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(45,'sinyeon',130000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(45,'kbm0225',126000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(46,'sinyeon',132000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(46,'kbm0225',170000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(46,'hojin',176000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(46,'hojin',132000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(46,'sinyeon',170000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(46,'kbm0225',176000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(47,'sinyeon',132000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(47,'kbm0225',170000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(47,'hojin',176000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(47,'hojin',185000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(47,'sinyeon',430000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(47,'kbm0225',420000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(48,'sinyeon',132000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(48,'kbm0225',170000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(48,'hojin',176000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(48,'hojin',90000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(48,'sinyeon',170000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(48,'kbm0225',176000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(49,'sinyeon',217000,'향수',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(49,'kbm0225',220000,'향수',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(49,'hojin',195000,'향수',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(49,'hojin',217000,'향수',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(49,'sinyeon',220000,'향수',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(49,'kbm0225',195000,'향수',1);


insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(50,'sinyeon',217000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(50,'kbm0225',220000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(50,'hojin',195000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(50,'hojin',217000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(50,'sinyeon',220000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(50,'kbm0225',195000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(51,'sinyeon',217000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(51,'kbm0225',220000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_STATUS) values(51,'hojin',195000,'onesize',1);

insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(51,'hojin',1040000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(51,'sinyeon',1070000,'onesize',1);
insert into sale(SALE_PRODUCTID,SALE_USERID,SALE_PRICE,SALE_SIZE,SALE_CHECK) values(51,'kbm0225',1000000,'onesize',1);



SELECT SALE_SIZE,SALE_PRICE,SALE_DATE from SALE WHERE SALE_CHECK = 1 ORDER BY SALE_DATE;
SELECT  * FROM sale;
commit;

---

## Cart

insert into cart(CART_USERID,CART_SALENO) values('sinyeon',1);
insert into cart(CART_USERID,CART_SALENO) values('sinyeon',3);
insert into cart(CART_USERID,CART_SALENO) values('sinyeon',5);
insert into cart(CART_USERID,CART_SALENO) values('sinyeon',7);
insert into cart(CART_USERID,CART_SALENO) values('hojin',2);
insert into cart(CART_USERID,CART_SALENO) values('hojin',4);
insert into cart(CART_USERID,CART_SALENO) values('hojin',6);
insert into cart(CART_USERID,CART_SALENO) values('kbm0225',8);
insert into cart(CART_USERID,CART_SALENO) values('kbm0225',9);
insert into cart(CART_USERID,CART_SALENO) values('kbm0225',10);

SELECT * FROM cart;
commit;

---

## Stock

INSERT INTO stock VALUES (1,0,1,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO stock VALUES (2,1,0,1,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO stock VALUES (3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3);
INSERT INTO stock VALUES (4,1,2,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO stock VALUES (5,1,2,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO stock VALUES (6,1,1,2,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO stock VALUES (7,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3);
INSERT INTO stock VALUES (8,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3);
INSERT INTO stock VALUES (9,1,2,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO stock VALUES (10,1,1,2,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO stock VALUES (11,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO stock VALUES (12,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3);
INSERT INTO stock VALUES (13,1,1,1,1,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO stock VALUES (14,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3);
INSERT INTO stock VALUES (15,1,1,1,1,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO stock VALUES (16,1,1,1,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO stock VALUES (17,1,1,1,1,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO stock VALUES (18,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3);
INSERT INTO stock VALUES (19,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3);
INSERT INTO stock VALUES (20,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3);
INSERT INTO stock VALUES (21,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,2,0);
INSERT INTO stock VALUES (22,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,2,0);
INSERT INTO stock VALUES (23,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3);
INSERT INTO stock VALUES (24,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3);
INSERT INTO stock VALUES (25,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3);
INSERT INTO stock VALUES (26,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0);
INSERT INTO stock VALUES (27,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3);
INSERT INTO stock VALUES (28,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3);
INSERT INTO stock VALUES (29,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1);
INSERT INTO stock VALUES (30,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1);
INSERT INTO stock VALUES (31,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1);
INSERT INTO stock VALUES (32,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1);
INSERT INTO stock VALUES (33,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1);
INSERT INTO stock VALUES (34,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1);
INSERT INTO stock VALUES (35,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1);
INSERT INTO stock VALUES (36,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1);
INSERT INTO stock VALUES (37,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1);
INSERT INTO stock VALUES (38,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1);
INSERT INTO stock VALUES (39,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1);
INSERT INTO stock VALUES (40,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1);
INSERT INTO stock VALUES (41,0,0,0,0,0,1,1,0,0,1,0,1,0,1,0,0,1,1,0,0,0,0,0,0);
INSERT INTO stock VALUES (42,0,0,0,0,0,0,1,0,0,0,1,1,0,1,0,0,1,1,0,1,1,0,0,0);
INSERT INTO stock VALUES (43,0,0,0,0,0,0,1,1,1,1,1,1,0,1,0,0,1,1,0,1,1,0,0,0);
INSERT INTO stock VALUES (44,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1);
INSERT INTO stock VALUES (45,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1);
INSERT INTO stock VALUES (46,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1);
INSERT INTO stock VALUES (47,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1);
INSERT INTO stock VALUES (48,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1);
INSERT INTO stock VALUES (49,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0);
INSERT INTO stock VALUES (50,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1);
INSERT INTO stock VALUES (51,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1);

SELECT  * FROM stock;
commit;

------
