import { EventBanner } from "../components/eventBanner/eventBanner";
import { Link } from 'react-router-dom';
import styles from "../components/home1/Home.module.css";
import { Mypage } from "../components/mypage/mypage.js";

const Mypagepage = () => {
  return (
    <>
      <Mypage></Mypage>
    </>
  )
}
export { Mypagepage };