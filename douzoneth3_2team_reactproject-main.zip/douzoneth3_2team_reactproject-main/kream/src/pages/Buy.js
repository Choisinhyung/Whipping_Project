import { BuyPay } from "../components/pay/BuyPay.js";

const Buy = () => {
  return (
    <BuyPay
    />
  )
}
export { Buy };