import { SellPay } from "../components/pay/SellPay.js";

const Sell = () => {
  return (
    <SellPay
    />
  )
}
export { Sell };