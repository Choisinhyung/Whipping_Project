import { Payment } from '../components/dummy/kakao'

const Kakao = () => {
  return (
      <Payment />
  )
}
export { Kakao };