import { CartBuyPay } from "../components/pay/CartBuyPay";

const CartBuy = () => {
    return (
        <CartBuyPay
        />
    )
}
export { CartBuy };