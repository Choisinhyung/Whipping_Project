import { Outlet } from "react-router-dom";
import { MainCategory } from "../components/category/main.js";

const Main = () => {

    return (
        <>
            <MainCategory/>
        </>
    );

};

export { Main };
